import type { Payment } from './subscriptions'
import type { Suggestion } from './customer-domain'
export interface AdminDashboard {
  total_customers: number; active_customers: number; suspended_customers: number
  active_subscriptions: number; expired_subscriptions: number; expiring_soon: number
  total_revenue: string; monthly_revenue: string
  recent_payments: Payment[]; latest_suggestions: Suggestion[]
}
